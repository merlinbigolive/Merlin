# Merlin Agency — Verified ₹100 Placement Payment

This package replaces the old `upi://pay` client-side flow with Razorpay Standard Checkout.

Flow:
Apply Now → Placement Terms → Secure Razorpay Checkout → server-side signature + captured-status verification → Host Details → Submit → Live Chat / WhatsApp.

## Required secrets

Create one Firebase Secret named `RAZORPAY_CONFIG` containing:

```json
{
  "keyId": "rzp_live_xxxxxxxxxx",
  "keySecret": "YOUR_RAZORPAY_KEY_SECRET",
  "webhookSecret": "YOUR_RAZORPAY_WEBHOOK_SECRET"
}
```

Create another Firebase Secret:

`MERLIN_ACCESS_TOKEN_SECRET`

Use a long random value.

Never put `keySecret` or `webhookSecret` in `apply.html` or GitHub.

## Deploy

From the Firebase project root:

```bash
firebase login
firebase use merlin-live-chat
firebase functions:secrets:set RAZORPAY_CONFIG
firebase functions:secrets:set MERLIN_ACCESS_TOKEN_SECRET
cd functions
npm install
cd ..
firebase deploy --only functions
```

Then configure the Razorpay webhook to:

`https://asia-south1-merlin-live-chat.cloudfunctions.net/razorpayWebhook`

Enable `payment.captured`.

The frontend is already configured for:

`https://asia-south1-merlin-live-chat.cloudfunctions.net`

## Important

The frontend does not unlock access merely because the UPI app opened or because the user returned from it.

The backend:
1. creates a Razorpay order for exactly ₹100;
2. verifies the Razorpay HMAC signature server-side;
3. checks that the payment belongs to the same order;
4. checks that the payment amount is ₹100 INR;
5. requires `captured` status before issuing the access token.

Razorpay's official integration guidance requires server-side order creation and signature verification before fulfilling a service.
